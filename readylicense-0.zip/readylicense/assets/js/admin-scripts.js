/**
 * ReadyLicense Admin Scripts
 * Handles Tabs, AJAX lists, and Settings.
 */
jQuery(document).ready(function($) {
    
    const adminObj = window.rl_obj || {};

    // --- 1. Tab Management ---
    $('.rl-sidebar li').on('click', function() {
        const tabId = $(this).data('tab');
        
        // Update Sidebar UI
        $('.rl-sidebar li').removeClass('active');
        $(this).addClass('active');

        // Show Content
        $('.rl-tab-content').removeClass('active');
        $('#tab-' + tabId).addClass('active');

        // Load data if needed (Lazy Loading)
        if (tabId === 'users' && $('#rl-users-list-body').is(':empty')) {
            loadUsers(1);
        }
        if (tabId === 'products' && $('#rl-products-list-body').is(':empty')) {
            loadProducts(1);
        }
    });

    // --- 2. Users Management ---
    let userSearchTimer;
    $('#rl-user-search').on('input', function() {
        clearTimeout(userSearchTimer);
        const query = $(this).val();
        userSearchTimer = setTimeout(function() {
            loadUsers(1, query);
        }, 500); // 500ms delay
    });

    function loadUsers(page, search = '') {
        const tbody = $('#rl-users-list-body');
        tbody.html('<tr><td colspan="2" style="text-align:center;">درحال بارگذاری...</td></tr>');

        $.ajax({
            url: adminObj.ajax_url,
            type: 'POST',
            data: {
                action: 'rl_admin_action',
                security: adminObj.nonce,
                request_type: 'get_users',
                paged: page,
                search: search
            },
            success: function(response) {
                if(response.success) {
                    tbody.html(response.data.html);
                    renderPagination('#rl-users-pagination', response.data.total_pages, page, 'users');
                } else {
                    tbody.html('<tr><td colspan="2">خطا در دریافت اطلاعات</td></tr>');
                }
            }
        });
    }

    // --- 3. Products Management ---
    let productSearchTimer;
    $('#rl-product-search').on('input', function() {
        clearTimeout(productSearchTimer);
        const query = $(this).val();
        productSearchTimer = setTimeout(function() {
            loadProducts(1, query);
        }, 500);
    });

    function loadProducts(page, search = '') {
        const tbody = $('#rl-products-list-body');
        tbody.html('<tr><td colspan="3" style="text-align:center;">درحال بارگذاری...</td></tr>');

        $.ajax({
            url: adminObj.ajax_url,
            type: 'POST',
            data: {
                action: 'rl_admin_action',
                security: adminObj.nonce,
                request_type: 'get_products',
                paged: page,
                search: search
            },
            success: function(response) {
                if(response.success) {
                    tbody.html(response.data.html);
                    renderPagination('#rl-products-pagination', response.data.total_pages, page, 'products');
                }
            }
        });
    }

    // Generate/Update Merchant Code
    $(document).on('click', '.generate-merchant', function(e) {
        e.preventDefault();
        const btn = $(this);
        const productId = btn.data('id');
        
        btn.addClass('updating').text('...');

        $.ajax({
            url: adminObj.ajax_url,
            type: 'POST',
            data: {
                action: 'rl_admin_action',
                security: adminObj.nonce,
                request_type: 'generate_merchant',
                product_id: productId
            },
            success: function(response) {
                if(response.success) {
                    btn.closest('tr').find('.code-box').text(response.data.code);
                    btn.text('تغییر کد');
                }
                btn.removeClass('updating');
            }
        });
    });

    // --- 4. Settings Form ---
    $('#rl-settings-form').on('submit', function(e) {
        e.preventDefault();
        const form = $(this);
        const btn = form.find('button[type="submit"]');
        const spinner = form.find('.spinner');

        btn.prop('disabled', true);
        spinner.addClass('is-active');

        $.ajax({
            url: adminObj.ajax_url,
            type: 'POST',
            data: {
                action: 'rl_admin_action',
                security: adminObj.nonce,
                request_type: 'save_settings',
                settings: getFormData(form) // Custom function to serialize to object
            },
            success: function(response) {
                if(response.success) {
                    alert(response.data.message || 'ذخیره شد');
                }
            },
            complete: function() {
                btn.prop('disabled', false);
                spinner.removeClass('is-active');
            }
        });
    });

    // Helper: Serialize form to simpler object (handling arrays like settings[key])
    function getFormData($form){
        var unindexed_array = $form.serializeArray();
        var indexed_array = {};

        $.map(unindexed_array, function(n, i){
            // Clean up name="settings[key]" to just "key"
            let name = n['name'].replace('settings[', '').replace(']', '');
            indexed_array[name] = n['value'];
        });

        return indexed_array;
    }

    // --- 5. Encoder ---
    $('#rl-btn-encode').on('click', function() {
        const code = $('#rl-raw-code').val();
        if(!code.trim()) return alert('کد خالی است!');

        const btn = $(this);
        btn.prop('disabled', true).text('درحال پردازش...');

        $.ajax({
            url: adminObj.ajax_url,
            type: 'POST',
            data: {
                action: 'rl_admin_action',
                security: adminObj.nonce,
                request_type: 'encode_code',
                code: code
            },
            success: function(response) {
                if(response.success) {
                    $('#rl-encoded-code').val(response.data.encoded);
                    $('#rl-encoded-result').slideDown();
                } else {
                    alert(response.data.message);
                }
            },
            complete: function() {
                btn.prop('disabled', false).text('رمزنگاری کن');
            }
        });
    });

    // --- Helper: Render Pagination ---
    function renderPagination(selector, totalPages, currentPage, type) {
        let html = '';
        if(totalPages <= 1) {
            $(selector).html('');
            return;
        }

        for (let i = 1; i <= totalPages; i++) {
            const activeClass = (i === currentPage) ? 'active' : '';
            html += `<button class="${activeClass}" data-page="${i}" data-type="${type}">${i}</button>`;
        }
        $(selector).html(html);
    }

    // Pagination Click
    $(document).on('click', '.rl-pagination button', function(e) {
        e.preventDefault();
        const page = $(this).data('page');
        const type = $(this).data('type');

        if(type === 'users') loadUsers(page, $('#rl-user-search').val());
        if(type === 'products') loadProducts(page, $('#rl-product-search').val());
    });

    // Initial Load
    // Auto click first tab if needed, but HTML has "active" class hardcoded initially
});
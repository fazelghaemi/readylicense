<?php

/**
 * مدیریت بخش‌های ظاهری سمت کاربر (Frontend)
 * * @package    ReadyLicense
 * @subpackage ReadyLicense/includes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ReadyLicense_Frontend {

	public function __construct() {
		// اضافه کردن تب لایسنس به "حساب کاربری من" در ووکامرس
		add_filter( 'woocommerce_account_menu_items', [ $this, 'add_my_account_tab' ] );
		add_action( 'init', [ $this, 'add_endpoint' ] );
		add_action( 'woocommerce_account_licenses_endpoint', [ $this, 'render_dashboard' ] );

		// شورت‌کد برای نمایش در صفحات دلخواه
		add_shortcode( 'ready_license_dashboard', [ $this, 'render_shortcode' ] );
	}

	/**
	 * اضافه کردن تب جدید به منوی حساب کاربری ووکامرس
	 */
	public function add_my_account_tab( $items ) {
		$license_label = get_option( 'readylicense_label_menu', 'لایسنس‌های من' );
		
		// درج در وسط منو (نه آخر)
		$new_items = [];
		$count = 0;
		$insert_index = 2; // بعد از داشبورد و سفارشات

		foreach ( $items as $key => $item ) {
			$new_items[ $key ] = $item;
			$count++;
			if ( $count === $insert_index ) {
				$new_items['licenses'] = $license_label;
			}
		}
		return $new_items;
	}

	/**
	 * ثبت Endpoint برای آدرس‌دهی زیبا (example.com/my-account/licenses)
	 */
	public function add_endpoint() {
		add_rewrite_endpoint( 'licenses', EP_ROOT | EP_PAGES );
	}

	/**
	 * تابع نمایش شورت‌کد
	 */
	public function render_shortcode() {
		ob_start();
		$this->render_dashboard();
		return ob_get_clean();
	}

	/**
	 * رندر کردن HTML داشبورد
	 * نکته مهم: اینجا هیچ HTMLی نمی‌نویسیم، فقط فایل تمپلت را فراخوانی می‌کنیم.
	 */
	public function render_dashboard() {
		if ( ! is_user_logged_in() ) {
			echo '<div class="rl-alert rl-error">' . __( 'لطفاً ابتدا وارد حساب کاربری خود شوید.', 'readylicense' ) . '</div>';
			return;
		}

		// آماده‌سازی متغیرها برای ارسال به ویو (View)
		$user_id = get_current_user_id();
		
		// بهینه‌سازی کوئری: فقط سفارشات تکمیل شده که محصول لایسنس‌دار دارند
		// این جایگزین کوئری سنگین قبلی است
		$args = [
			'customer_id' => $user_id,
			'status'      => 'completed',
			'limit'       => -1,
			'type'        => 'shop_order',
			'return'      => 'ids', // فقط آی‌دی‌ها را بگیر که سبک باشد
		];
		
		$order_ids = wc_get_orders( $args );
		$licenses_data = $this->prepare_licenses_data( $order_ids, $user_id );

		// بارگذاری فایل تمپلت
		include RL_PLUGIN_DIR . 'templates/dashboard.php';
	}

	/**
	 * پردازش و آماده‌سازی داده‌ها قبل از نمایش
	 * این تابع منطق پیچیده را از فایل HTML جدا می‌کند
	 */
	private function prepare_licenses_data( $order_ids, $user_id ) {
		$data = [];
		
		if ( empty( $order_ids ) ) return $data;

		foreach ( $order_ids as $order_id ) {
			$order = wc_get_order( $order_id );
			if ( ! $order ) continue;

			// اگر سفارش تمدید است، رد شو (مگر اینکه بخواهید لاگ نمایش دهید)
			if ( $order->get_meta( '_is_readylicense_renewal' ) === 'yes' ) continue;

			foreach ( $order->get_items() as $item_id => $item ) {
				$product_id = $item->get_product_id();
				
				// بررسی شرط "عدم نمایش در پنل"
				if ( get_post_meta( $product_id, '_rl_exclude_from_panel', true ) === 'yes' ) continue;

				// دریافت دامین‌ها و وضعیت‌ها
				$meta_key_domains = "_rl_user_domains_{$user_id}_{$product_id}_{$item_id}";
				$domains = get_post_meta( $product_id, $meta_key_domains, true ) ?: [];
				
				$data[] = [
					'product_name'   => $item->get_name(),
					'product_url'    => get_permalink( $product_id ),
					'product_id'     => $product_id,
					'order_item_id'  => $item_id, // کلید یکتا برای هر آیتم سفارش
					'domains'        => $domains,
					'max_domains'    => get_option( 'readylicense_max_domains', 3 ),
					'current_count'  => count( is_array($domains) ? $domains : [] ),
					'renewal_price'  => get_post_meta( $product_id, '_rl_renewal_price', true ),
					'duration'       => get_post_meta( $product_id, '_rl_duration', true ),
				];
			}
		}
		return $data;
	}
}
<?php

/**
 * مدیریت تمام درخواست‌های AJAX (Admin & Frontend)
 * جایگزین توابع save_license و renew_license در فایل user.php قدیمی
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ReadyLicense_Ajax {

	public function __construct() {
		// هندلر واحد برای تمام درخواست‌های فرانت‌اند
		add_action( 'wp_ajax_rl_handle_frontend_request', [ $this, 'handle_frontend_request' ] );
		
		// برای کاربران لاگین نکرده (اگر نیاز بود، فعلا غیرفعال)
		// add_action( 'wp_ajax_nopriv_rl_handle_frontend_request', [ $this, 'handle_frontend_request' ] );
	}

	/**
	 * تابع مرکزی مدیریت درخواست‌ها
	 * این روش باعث می‌شود فقط یک هوک AJAX داشته باشیم و سرور کمتر درگیر شود.
	 */
	public function handle_frontend_request() {
		// 1. بررسی امنیت (Nonce)
		check_ajax_referer( 'rl_user_nonce', 'security' );

		// 2. دریافت نوع درخواست
		$request_type = isset( $_POST['request_type'] ) ? sanitize_text_field( $_POST['request_type'] ) : '';
		
		try {
			switch ( $request_type ) {
				case 'save_domain':
					$this->save_domain();
					break;
				
				case 'renew_license':
					$this->create_renewal_order();
					break;

				default:
					throw new Exception( __( 'درخواست نامعتبر است.', 'readylicense' ) );
			}
		} catch ( Exception $e ) {
			wp_send_json_error( [ 'message' => $e->getMessage() ] );
		}
	}

	/**
	 * منطق ذخیره دامین جدید
	 */
	private function save_domain() {
		$user_id       = get_current_user_id();
		$domain        = $this->sanitize_domain( $_POST['domain'] );
		$product_id    = intval( $_POST['product_id'] );
		$order_item_id = intval( $_POST['order_item_id'] );

		if ( ! $domain ) {
			throw new Exception( __( 'فرمت دامنه نامعتبر است.', 'readylicense' ) );
		}

		// کلید متای یونیک برای ذخیره
		$meta_key_domains = "_rl_user_domains_{$user_id}_{$product_id}_{$order_item_id}";
		$current_domains  = get_post_meta( $product_id, $meta_key_domains, true );
		
		if ( ! is_array( $current_domains ) ) $current_domains = [];

		// بررسی محدودیت تعداد
		$limit = intval( get_option( 'readylicense_max_domains', 3 ) );
		if ( count( $current_domains ) >= $limit ) {
			throw new Exception( __( 'محدودیت تعداد دامنه برای این لایسنس پر شده است.', 'readylicense' ) );
		}

		// بررسی تکراری نبودن
		if ( in_array( $domain, $current_domains ) ) {
			throw new Exception( __( 'این دامنه قبلاً ثبت شده است.', 'readylicense' ) );
		}

		// افزودن دامنه جدید
		$current_domains[] = $domain;
		update_post_meta( $product_id, $meta_key_domains, $current_domains );

		// ثبت وضعیت اولیه و تاریخ انقضا
		$duration = get_post_meta( $product_id, '_rl_duration', true );
		$expiry   = $duration ? date( 'Y-m-d H:i:s', strtotime( "+$duration days" ) ) : null;
		
		update_user_meta( $user_id, "rl_status_{$product_id}_{$domain}", 'active' );
		if ( $expiry ) {
			update_user_meta( $user_id, "rl_expiry_{$product_id}_{$order_item_id}_{$domain}", $expiry );
		}

		wp_send_json_success( [
			'message' => __( 'دامنه با موفقیت ثبت شد.', 'readylicense' ),
			'domain'  => $domain,
			'status'  => 'active',
			'expiry'  => $expiry ? date_i18n( get_option( 'date_format' ), strtotime( $expiry ) ) : __( 'نامحدود', 'readylicense' )
		] );
	}

	/**
	 * ایجاد سفارش تمدید در ووکامرس
	 */
	private function create_renewal_order() {
		$product_id = intval( $_POST['product_id'] );
		$domain     = sanitize_text_field( $_POST['domain'] );
		$price      = floatval( $_POST['price'] );
		$user_id    = get_current_user_id();

		// ساخت سفارش برنامه‌نویسی شده
		$order = wc_create_order( [
			'customer_id' => $user_id,
			'status'      => 'pending',
			'parent'      => 0,
			'created_via' => 'readylicense_renewal'
		] );

		if ( is_wp_error( $order ) ) {
			throw new Exception( $order->get_error_message() );
		}

		// افزودن محصول به سفارش
		$item_id = $order->add_product( wc_get_product( $product_id ), 1, [
			'subtotal' => $price,
			'total'    => $price
		] );

		// افزودن متادیتا برای شناسایی تمدید بعد از پرداخت
		$order->update_meta_data( '_is_readylicense_renewal', 'yes' );
		$order->update_meta_data( '_renewal_domain', $domain );
		$order->calculate_totals();
		$order->save();

		wp_send_json_success( [
			'message'      => __( 'فاکتور تمدید ایجاد شد. در حال انتقال به درگاه...', 'readylicense' ),
			'redirect_url' => $order->get_checkout_payment_url()
		] );
	}

	/**
	 * تمیز کردن آدرس دامنه
	 */
	private function sanitize_domain( $url ) {
		$url = trim( $url );
		$url = preg_replace( '#^https?://#', '', $url );
		$url = preg_replace( '#^www\.#', '', $url );
		$url = explode( '/', $url )[0]; // حذف مسیرهای اضافی
		
		// اعتبارسنجی ساده
		if ( ! preg_match( '/^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i', $url ) ) {
			return false;
		}
		return strtolower( $url );
	}
}
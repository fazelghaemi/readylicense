<?php

/**
 * Fired during plugin activation
 *
 * @link       https://readylicense.com
 * @since      2.0.0
 * @package    ReadyLicense
 * @subpackage ReadyLicense/includes
 */

// امنیت: جلوگیری از دسترسی مستقیم
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ReadyLicense_Activator {

	/**
	 * متد اصلی که هنگام فعال‌سازی افزونه اجرا می‌شود
	 */
	public static function activate() {
		self::create_database_tables();
		self::migrate_old_data();
		
		// بازنویسی قوانین پیوند یکتا (اگر از API Endpoint استفاده می‌کنید)
		flush_rewrite_rules();
	}

	/**
	 * ایجاد جداول دیتابیس
	 * استفاده از dbDelta استاندارد وردپرس برای جلوگیری از ارورهای SQL
	 */
	private static function create_database_tables() {
		global $wpdb;

		$table_name = $wpdb->prefix . 'readylicense_keys';
		$charset_collate = $wpdb->get_charset_collate();

		// ساختار پیشنهادی جدول لایسنس‌ها (بر اساس فیلدهای معمول)
		$sql = "CREATE TABLE $table_name (
			id mediumint(9) NOT NULL AUTO_INCREMENT,
			license_key varchar(100) NOT NULL,
			product_id bigint(20) NOT NULL,
			user_id bigint(20) NOT NULL,
			order_id bigint(20) DEFAULT 0,
			status varchar(20) DEFAULT 'inactive',
			activation_limit int(5) DEFAULT 1,
			activation_count int(5) DEFAULT 0,
			expiration_date datetime DEFAULT '0000-00-00 00:00:00',
			created_at datetime DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY license_key (license_key),
			KEY user_id (user_id)
		) $charset_collate;";

		// جدول لاگ‌ها (برای دیباگ و امنیت)
		$table_logs = $wpdb->prefix . 'readylicense_logs';
		$sql_logs = "CREATE TABLE $table_logs (
			id mediumint(9) NOT NULL AUTO_INCREMENT,
			license_id mediumint(9) NOT NULL,
			action varchar(50) NOT NULL,
			ip_address varchar(45) NOT NULL,
			domain varchar(255) NOT NULL,
			log_date datetime DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id)
		) $charset_collate;";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );
		dbDelta( $sql_logs );
	}

	/**
	 * انتقال اطلاعات از افزونه قدیمی (License-Plus) به جدید
	 * این بخش حیاتی برای ریبرندینگ است
	 */
	private static function migrate_old_data() {
		global $wpdb;

		// 1. تغییر نام جدول قدیمی به جدید (اگر وجود داشت)
		$old_table = $wpdb->prefix . 'license_plus_keys'; // نام احتمالی جدول قدیم
		$new_table = $wpdb->prefix . 'readylicense_keys';

		// چک می‌کنیم اگر جدول قدیم هست ولی جدول جدید خالی است، تغییر نام بده
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$old_table'" ) === $old_table && 
		     $wpdb->get_var( "SELECT COUNT(*) FROM $new_table" ) == 0 ) {
			
			$wpdb->query( "INSERT INTO $new_table SELECT * FROM $old_table" );
			// بعد از اطمینان می‌توان جدول قدیم را حذف کرد یا نگه داشت
		}

		// 2. انتقال تنظیمات (Options)
		$old_options = get_option( 'license_plus_settings' );
		$new_options = get_option( 'readylicense_settings' );

		if ( $old_options && ! $new_options ) {
			update_option( 'readylicense_settings', $old_options );
			// آپشن قدیمی را پاک نمی‌کنیم تا راه برگشت باشد
		}
	}
}
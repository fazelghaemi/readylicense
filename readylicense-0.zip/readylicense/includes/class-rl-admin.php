<?php

/**
 * The admin-specific functionality of the plugin.
 * Handles dashboard rendering, settings saving, and admin AJAX requests.
 *
 * @package    ReadyLicense
 * @subpackage ReadyLicense/includes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ReadyLicense_Admin {

	private $plugin_name;
	private $version;

	public function __construct() {
		$this->plugin_name = 'readylicense';
		$this->version     = RL_VERSION;

		// ثبت منوی ادمین
		add_action( 'admin_menu', [ $this, 'add_plugin_admin_menu' ] );

		// هندلر مرکزی AJAX برای ادمین
		add_action( 'wp_ajax_rl_admin_action', [ $this, 'handle_admin_ajax' ] );
	}

	/**
	 * افزودن منوی اصلی به پیشخوان وردپرس
	 */
	public function add_plugin_admin_menu() {
		add_menu_page(
			__( 'ReadyLicense', 'readylicense' ),
			__( 'ReadyLicense', 'readylicense' ),
			'manage_options',
			'readylicense',
			[ $this, 'display_plugin_admin_dashboard' ],
			'dashicons-shield',
			26
		);
	}

	/**
	 * نمایش فایل ویو (HTML) داشبورد
	 */
	public function display_plugin_admin_dashboard() {
		// بارگذاری فایل تمپلت یکپارچه
		require_once RL_PLUGIN_DIR . 'templates/admin-dashboard.php';
	}

	/**
	 * مدیریت تمام درخواست‌های AJAX پنل ادمین
	 */
	public function handle_admin_ajax() {
		// بررسی امنیت
		check_ajax_referer( 'rl_admin_nonce', 'security' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'عدم دسترسی.', 'readylicense' ) ] );
		}

		$request_type = isset( $_POST['request_type'] ) ? sanitize_text_field( $_POST['request_type'] ) : '';

		switch ( $request_type ) {
			case 'get_users':
				$this->ajax_get_users_list();
				break;
			
			case 'get_products':
				$this->ajax_get_products_list();
				break;

			case 'generate_merchant':
				$this->ajax_generate_merchant_code();
				break;

			case 'save_settings':
				$this->ajax_save_settings();
				break;
			
			case 'encode_code':
				$this->ajax_encode_php_code();
				break;

			default:
				wp_send_json_error( [ 'message' => __( 'درخواست نامعتبر.', 'readylicense' ) ] );
		}
	}

	/**
	 * دریافت لیست کاربران (بهینه شده)
	 * جایگزین تابع کند قدیمی که همه سفارشات را می‌گرفت
	 */
	private function ajax_get_users_list() {
		global $wpdb;

		$paged  = isset( $_POST['paged'] ) ? intval( $_POST['paged'] ) : 1;
		$search = isset( $_POST['search'] ) ? sanitize_text_field( $_POST['search'] ) : '';
		$limit  = 10;
		$offset = ( $paged - 1 ) * $limit;

		// کوئری مستقیم و سریع از جدول کاربران
		$args = [
			'number' => $limit,
			'offset' => $offset,
			'fields' => [ 'ID', 'user_login', 'display_name', 'user_email' ],
		];

		if ( ! empty( $search ) ) {
			$args['search'] = '*' . $search . '*';
			$args['search_columns'] = [ 'user_login', 'user_email', 'display_name' ];
		}

		$user_query = new WP_User_Query( $args );
		$users      = $user_query->get_results();
		$total_users = $user_query->get_total();

		$html = '';
		if ( ! empty( $users ) ) {
			foreach ( $users as $user ) {
				$html .= sprintf(
					'<tr>
						<td>
							<strong>%s</strong><br>
							<small>%s</small>
						</td>
						<td>
							<button class="rl-btn rl-btn-small rl-btn-secondary view-user-licenses" data-id="%d">%s</button>
						</td>
					</tr>',
					esc_html( $user->display_name ?: $user->user_login ),
					esc_html( $user->user_email ),
					$user->ID,
					__( 'مشاهده لایسنس‌ها', 'readylicense' )
				);
			}
		} else {
			$html = '<tr><td colspan="2">' . __( 'کاربری یافت نشد.', 'readylicense' ) . '</td></tr>';
		}

		wp_send_json_success( [
			'html'        => $html,
			'total_pages' => ceil( $total_users / $limit )
		] );
	}

	/**
	 * دریافت لیست محصولات برای لایسنس گذاری
	 */
	private function ajax_get_products_list() {
		$paged  = isset( $_POST['paged'] ) ? intval( $_POST['paged'] ) : 1;
		$search = isset( $_POST['search'] ) ? sanitize_text_field( $_POST['search'] ) : '';
		
		$args = [
			'post_type'      => 'product',
			'posts_per_page' => 10,
			'paged'          => $paged,
			'post_status'    => 'publish',
		];

		if ( ! empty( $search ) ) {
			$args['s'] = $search;
		}

		$query = new WP_Query( $args );
		$html  = '';

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$product_id = get_the_ID();
				$merchant   = get_post_meta( $product_id, '_rl_license_code', true ) ?: '-';

				$html .= sprintf(
					'<tr>
						<td>%s</td>
						<td class="code-box">%s</td>
						<td><button class="rl-btn rl-btn-primary generate-merchant" data-id="%d">%s</button></td>
					</tr>',
					get_the_title(),
					esc_html( $merchant ),
					$product_id,
					( $merchant === '-' ? __( 'تولید کد', 'readylicense' ) : __( 'تغییر کد', 'readylicense' ) )
				);
			}
			wp_reset_postdata();
		} else {
			$html = '<tr><td colspan="3">' . __( 'محصولی یافت نشد.', 'readylicense' ) . '</td></tr>';
		}

		wp_send_json_success( [
			'html'        => $html,
			'total_pages' => $query->max_num_pages
		] );
	}

	/**
	 * تولید کد مرچنت (جایگزین تابع‌های پراکنده)
	 */
	private function ajax_generate_merchant_code() {
		$product_id = intval( $_POST['product_id'] );
		$new_code   = 'RL-' . strtoupper( bin2hex( random_bytes( 8 ) ) );
		
		update_post_meta( $product_id, '_rl_license_code', $new_code );
		wp_send_json_success( [ 'code' => $new_code ] );
	}

	/**
	 * ذخیره تنظیمات (تجمیع تنظیمات عمومی و لیبل‌ها)
	 */
	private function ajax_save_settings() {
		$data = isset( $_POST['settings'] ) ? $_POST['settings'] : [];
		
		// لیست فیلدهای مجاز برای امنیت
		$allowed_options = [
			'readylicense_max_domains',
			'readylicense_label_menu',
			'readylicense_label_product',
			// ... سایر فیلدها را اینجا اضافه کنید
		];

		foreach ( $data as $key => $value ) {
			// اگر می‌خواهید سخت‌گیری کنید، چک کنید key در allowed_options باشد
			update_option( sanitize_key( $key ), sanitize_textarea_field( $value ) );
		}

		wp_send_json_success( [ 'message' => __( 'تنظیمات با موفقیت ذخیره شد.', 'readylicense' ) ] );
	}

	/**
	 * رمزنگاری کد PHP (بهینه شده و ایمن‌تر)
	 */
	private function ajax_encode_php_code() {
		if ( empty( $_POST['code'] ) ) {
			wp_send_json_error( [ 'message' => __( 'کد نمی‌تواند خالی باشد.', 'readylicense' ) ] );
		}

		$raw_code = wp_unslash( $_POST['code'] );
		
		// حذف تگ‌های PHP اگر وجود داشته باشند
		$clean_code = preg_replace( '/^<\?php\s*/i', '', $raw_code );
		$clean_code = preg_replace( '/\s*\?>$/i', '', $clean_code );

		// رمزنگاری ساده (پیشنهاد می‌شود از کتابخانه‌های قوی‌تر استفاده کنید)
		// اینجا منطق `encoder.php` شما را بازنویسی و تمیز می‌کنم
		$key = openssl_random_pseudo_bytes(32);
		$iv  = openssl_random_pseudo_bytes(16); // AES-256-CBC needs 16 bytes IV
		
		$encrypted = openssl_encrypt( $clean_code, 'AES-256-CBC', $key, 0, $iv );
		
		// ساخت کد خروجی که قابلیت اجرا داشته باشد
		$key_hex = bin2hex($key);
		$iv_hex  = bin2hex($iv);
		
		$final_output = "<?php\n";
		$final_output .= "/* Encoded by ReadyLicense */\n";
		$final_output .= "\$k='$key_hex';\$i='$iv_hex';\$e='$encrypted';";
		$final_output .= "eval(openssl_decrypt(\$e, 'AES-256-CBC', hex2bin(\$k), 0, hex2bin(\$i)));";
		
		wp_send_json_success( [ 'encoded' => $final_output ] );
	}
}
<?php
/*
Plugin Name: ReadyLicense
Plugin URI: https://readylicense.com
Description: سیستم حرفه‌ای و سبک مدیریت لایسنس محصولات ووکامرس.
Version: 2.0.0
Author: ReadyStudio
Text Domain: readylicense
Domain Path: /languages
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// تعریف ثابت‌های مسیر
define( 'RL_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'RL_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'RL_VERSION', '2.0.0' );

/**
 * کلاس اصلی راه‌انداز افزونه
 */
class ReadyLicense_Core {

    public function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }

    /**
     * بارگذاری فایل‌های کلاس مورد نیاز
     */
    private function load_dependencies() {
        // ۱. کلاس فعال‌سازی و دیتابیس
        require_once RL_PLUGIN_DIR . 'includes/class-rl-activator.php';
        
        // ۲. کلاس مدیریت پنل ادمین (جایگزین panel.php و setting.php قدیمی)
        require_once RL_PLUGIN_DIR . 'includes/class-rl-admin.php';
        
        // ۳. کلاس بخش کاربری (جایگزین user.php قدیمی)
        require_once RL_PLUGIN_DIR . 'includes/class-rl-frontend.php';
        
        // ۴. کلاس پردازش AJAX
        require_once RL_PLUGIN_DIR . 'includes/class-rl-ajax.php';
    }

    /**
     * اجرای هوک‌ها
     */
    private function init_hooks() {
        // راه‌اندازی بخش ادمین
        $plugin_admin = new ReadyLicense_Admin();
        
        // راه‌اندازی بخش کاربری
        $plugin_public = new ReadyLicense_Frontend();
        
        // راه‌اندازی AJAX
        $plugin_ajax = new ReadyLicense_Ajax();

        // بارگذاری استایل‌ها و اسکریپت‌های ادمین (فقط در صفحه افزونه)
        add_action( 'admin_enqueue_scripts', function( $hook ) {
            // فقط اگر در صفحه مربوط به ReadyLicense هستیم فایل‌ها را لود کن
            if ( strpos( $hook, 'readylicense' ) === false ) {
                return;
            }

            wp_enqueue_style( 'rl-admin-css', RL_PLUGIN_URL . 'assets/css/admin-styles.css', [], RL_VERSION );
            wp_enqueue_script( 'rl-admin-js', RL_PLUGIN_URL . 'assets/js/admin-scripts.js', ['jquery'], RL_VERSION, true );

            wp_localize_script( 'rl-admin-js', 'rl_obj', [
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce'    => wp_create_nonce( 'rl_admin_nonce' )
            ]);
        });

        // بارگذاری استایل‌ها و اسکریپت‌های فرانت (فقط در صفحات مربوطه)
        add_action( 'wp_enqueue_scripts', function() {
            global $post;
            
            // شرط هوشمند: فقط در صفحه اکانت یا صفحه‌ای که شورت‌کد دارد
            $is_account = function_exists('is_account_page') && is_account_page();
            $has_shortcode = is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'ready_license_dashboard' );

            if ( ! $is_account && ! $has_shortcode ) {
                return;
            }

            wp_enqueue_style( 'rl-front-css', RL_PLUGIN_URL . 'assets/css/style.css', [], RL_VERSION );
            wp_enqueue_script( 'rl-user-js', RL_PLUGIN_URL . 'assets/js/user-script.js', [], RL_VERSION, true );
            
            wp_localize_script( 'rl-user-js', 'rl_front', [
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce'    => wp_create_nonce( 'rl_user_nonce' )
            ]);
        });
    }
}

// هوک فعال‌سازی افزونه (ساخت جداول دیتابیس)
register_activation_hook( __FILE__, [ 'ReadyLicense_Activator', 'activate' ] );

// اجرای سیستم
new ReadyLicense_Core();
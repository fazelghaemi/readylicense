<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// دریافت تنظیمات فعلی برای پر کردن فرم‌ها
$max_domains = get_option( 'readylicense_max_domains', 3 );
?>

<div class="wrap rl-admin-wrapper">
    
    <!-- هدر داشبورد -->
    <div class="rl-header">
        <div class="rl-logo">
            <!-- نمایش لوگوی اختصاصی -->
            <img src="<?php echo RL_PLUGIN_URL . 'assets/img/readystudio-logo.png'; ?>" alt="ReadyLicense" class="rl-logo-img">
            <h1>ReadyLicense <small>v<?php echo RL_VERSION; ?></small></h1>
        </div>
        <div class="rl-actions">
            <a href="https://readylicense.com/docs" target="_blank" class="rl-btn rl-btn-secondary">
                <span class="dashicons dashicons-text-page" style="margin-left:5px;"></span> <?php _e( 'مستندات', 'readylicense' ); ?>
            </a>
        </div>
    </div>

    <div class="rl-container">
        
        <!-- سایدبار منو -->
        <nav class="rl-sidebar">
            <ul>
                <li class="active" data-tab="users">
                    <span class="dashicons dashicons-admin-users"></span> <?php _e( 'مدیریت کاربران', 'readylicense' ); ?>
                </li>
                <li data-tab="products">
                    <span class="dashicons dashicons-cart"></span> <?php _e( 'لایسنس محصولات', 'readylicense' ); ?>
                </li>
                <li data-tab="settings">
                    <span class="dashicons dashicons-admin-settings"></span> <?php _e( 'تنظیمات', 'readylicense' ); ?>
                </li>
                <li data-tab="encoder">
                    <span class="dashicons dashicons-lock"></span> <?php _e( 'کدگذار PHP', 'readylicense' ); ?>
                </li>
                <li data-tab="help">
                    <span class="dashicons dashicons-editor-help"></span> <?php _e( 'راهنما', 'readylicense' ); ?>
                </li>
            </ul>
        </nav>

        <!-- محتوای تب‌ها -->
        <div class="rl-content">

            <!-- تب کاربران -->
            <div id="tab-users" class="rl-tab-content active">
                <h2><?php _e( 'لیست کاربران دارای لایسنس', 'readylicense' ); ?></h2>
                <div class="rl-tools">
                    <input type="text" id="rl-user-search" placeholder="<?php _e( 'جستجو (نام، ایمیل...)', 'readylicense' ); ?>">
                </div>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e( 'کاربر', 'readylicense' ); ?></th>
                            <th style="width: 150px;"><?php _e( 'عملیات', 'readylicense' ); ?></th>
                        </tr>
                    </thead>
                    <tbody id="rl-users-list-body">
                        <!-- پر شده توسط AJAX -->
                    </tbody>
                </table>
                <div id="rl-users-pagination" class="rl-pagination"></div>
                
                <!-- کانتینر نمایش جزئیات لایسنس کاربر -->
                <div id="rl-user-licenses-detail" style="display:none; margin-top: 20px; background: #f8f9fa; padding: 20px; border-radius: 8px; border: 1px solid #dadce0;">
                    <!-- جزئیات اینجا لود می‌شود -->
                </div>
            </div>

            <!-- تب محصولات -->
            <div id="tab-products" class="rl-tab-content">
                <h2><?php _e( 'مدیریت محصولات ووکامرس', 'readylicense' ); ?></h2>
                <div class="rl-tools">
                    <input type="text" id="rl-product-search" placeholder="<?php _e( 'جستجوی محصول...', 'readylicense' ); ?>">
                </div>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e( 'نام محصول', 'readylicense' ); ?></th>
                            <th><?php _e( 'کد مرچنت (Merchant Code)', 'readylicense' ); ?></th>
                            <th style="width: 150px;"><?php _e( 'عملیات', 'readylicense' ); ?></th>
                        </tr>
                    </thead>
                    <tbody id="rl-products-list-body">
                        <!-- پر شده توسط AJAX -->
                    </tbody>
                </table>
                <div id="rl-products-pagination" class="rl-pagination"></div>
            </div>

            <!-- تب تنظیمات -->
            <div id="tab-settings" class="rl-tab-content">
                <h2><?php _e( 'پیکربندی افزونه', 'readylicense' ); ?></h2>
                <form id="rl-settings-form">
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="readylicense_max_domains"><?php _e( 'حداکثر دامنه مجاز', 'readylicense' ); ?></label></th>
                            <td>
                                <input name="settings[readylicense_max_domains]" type="number" id="readylicense_max_domains" value="<?php echo esc_attr( $max_domains ); ?>" class="regular-text">
                                <p class="description"><?php _e( 'تعداد دامنه‌هایی که کاربر می‌تواند برای یک خرید ثبت کند.', 'readylicense' ); ?></p>
                            </td>
                        </tr>
                        
                        <!-- ادغام تنظیمات لیبل‌ها در همین جا -->
                        <tr>
                            <th colspan="2"><h3 style="margin-top: 20px; border-top: 1px solid #eee; padding-top: 20px;"><?php _e( 'ترجمه و متن‌ها (Labels)', 'readylicense' ); ?></h3></th>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php _e( 'عنوان منوی کاربری', 'readylicense' ); ?></label></th>
                            <td>
                                <input name="settings[readylicense_label_menu]" type="text" value="<?php echo get_option( 'readylicense_label_menu', 'لایسنس‌های من' ); ?>" class="regular-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php _e( 'عنوان ستون محصول', 'readylicense' ); ?></label></th>
                            <td>
                                <input name="settings[readylicense_label_product]" type="text" value="<?php echo get_option( 'readylicense_label_product', 'محصول' ); ?>" class="regular-text">
                            </td>
                        </tr>

                    </table>
                    <p class="submit">
                        <button type="submit" class="rl-btn rl-btn-primary"><?php _e( 'ذخیره تغییرات', 'readylicense' ); ?></button>
                        <span class="spinner"></span>
                    </p>
                </form>
            </div>

            <!-- تب اینکودر -->
            <div id="tab-encoder" class="rl-tab-content">
                <h2><?php _e( 'محافظت از کد (PHP Encoder)', 'readylicense' ); ?></h2>
                <p class="description"><?php _e( 'کد PHP خود را وارد کنید تا به صورت رمزنگاری شده تحویل بگیرید.', 'readylicense' ); ?></p>
                
                <textarea id="rl-raw-code" rows="10" class="code" placeholder="<?php _e( 'کد PHP را اینجا پیست کنید...', 'readylicense' ); ?>"></textarea>
                <br><br>
                <button type="button" id="rl-btn-encode" class="rl-btn rl-btn-primary"><?php _e( 'رمزنگاری کن', 'readylicense' ); ?></button>
                
                <div id="rl-encoded-result" style="display:none; margin-top: 20px;">
                    <h3><?php _e( 'کد رمزنگاری شده:', 'readylicense' ); ?></h3>
                    <textarea id="rl-encoded-code" rows="10" class="code" readonly></textarea>
                    <p class="description"><?php _e( 'این کد را جایگزین کد اصلی در فایل‌های قالب یا افزونه خود کنید.', 'readylicense' ); ?></p>
                </div>
            </div>

            <!-- تب راهنما -->
            <div id="tab-help" class="rl-tab-content">
                <h2><?php _e( 'راهنمای اتصال', 'readylicense' ); ?></h2>
                <p><?php _e( 'برای بررسی لایسنس در افزونه یا قالب خود، از کد زیر استفاده کنید:', 'readylicense' ); ?></p>
                <textarea rows="15" class="code" readonly dir="ltr">
// Sample Check Code
$license_code = 'MERCHANT_CODE_HERE';
$domain = $_SERVER['HTTP_HOST'];
$api_url = '<?php echo home_url( '/' ); ?>'; 

// Send Request to API...
                </textarea>
            </div>

        </div>
    </div>
</div>
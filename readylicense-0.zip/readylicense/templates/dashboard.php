<?php
/**
 * Template for User Dashboard (Licenses List)
 * * @var array $licenses_data آرایه داده‌های پاس داده شده از کنترلر
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// دریافت تنظیمات متنی از آپشن‌ها (با مقدار پیش‌فرض)
$label_product = get_option( 'readylicense_label_product', 'محصول' );
$label_domain  = get_option( 'readylicense_label_domain', 'مدیریت دامنه' );
$label_status  = get_option( 'readylicense_label_status', 'وضعیت / انقضا' );
$label_action  = get_option( 'readylicense_label_action', 'عملیات' );
?>

<div id="readylicense-user-panel" class="rl-dashboard-wrapper">
    
    <!-- باکس اعلان‌ها (توسط JS پر می‌شود) -->
    <div id="rl-alert-box" style="display:none;"></div>

    <?php if ( empty( $licenses_data ) ) : ?>
        <div class="rl-empty-state">
            <p><?php esc_html_e( 'هنوز هیچ لایسنسی برای شما ثبت نشده است.', 'readylicense' ); ?></p>
        </div>
    <?php else : ?>

        <div class="rl-responsive-table">
            <table class="rl-table">
                <thead>
                    <tr>
                        <th><?php echo esc_html( $label_product ); ?></th>
                        <th><?php echo esc_html( $label_domain ); ?></th>
                        <th><?php echo esc_html( $label_status ); ?></th>
                        <th><?php echo esc_html( $label_action ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $licenses_data as $license ) : ?>
                        <tr class="rl-license-row" data-id="<?php echo esc_attr( $license['order_item_id'] ); ?>">
                            
                            <!-- ستون نام محصول -->
                            <td class="rl-col-product">
                                <a href="<?php echo esc_url( $license['product_url'] ); ?>" target="_blank">
                                    <strong><?php echo esc_html( $license['product_name'] ); ?></strong>
                                </a>
                                <div class="rl-meta">
                                    <small><?php printf( __( '%d از %d دامنه استفاده شده', 'readylicense' ), $license['current_count'], $license['max_domains'] ); ?></small>
                                </div>
                            </td>

                            <!-- ستون دامین‌ها -->
                            <td class="rl-col-domains">
                                <?php if ( ! empty( $license['domains'] ) ) : ?>
                                    <ul class="rl-domain-list">
                                        <?php foreach ( $license['domains'] as $domain ) : ?>
                                            <li>
                                                <span class="dashicons dashicons-admin-site"></span>
                                                <?php echo esc_html( $domain ); ?>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else : ?>
                                    <span class="rl-badge rl-badge-info"><?php _e( 'دامنه‌ای ثبت نشده', 'readylicense' ); ?></span>
                                <?php endif; ?>
                            </td>

                            <!-- ستون وضعیت -->
                            <td class="rl-col-status">
                                <?php if ( ! empty( $license['domains'] ) ) : ?>
                                    <?php foreach ( $license['domains'] as $domain ) : 
                                        $user_id = get_current_user_id();
                                        $expiry_key = "rl_expiry_{$license['product_id']}_{$license['order_item_id']}_{$domain}";
                                        $expiry = get_user_meta( $user_id, $expiry_key, true );
                                        $days_left = $expiry ? ceil( ( strtotime( $expiry ) - time() ) / 86400 ) : 9999;
                                        
                                        $status_class = $days_left > 0 ? 'active' : 'expired';
                                        $status_text  = $days_left > 0 ? sprintf( __( '%d روز مانده', 'readylicense' ), $days_left ) : __( 'منقضی شده', 'readylicense' );
                                        if ( $days_left > 3000 ) $status_text = __( 'نامحدود', 'readylicense' );
                                    ?>
                                        <div class="rl-status-row">
                                            <span class="rl-badge rl-badge-<?php echo $status_class; ?>">
                                                <?php echo $status_text; ?>
                                            </span>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    -
                                <?php endif; ?>
                            </td>

                            <!-- ستون عملیات -->
                            <td class="rl-col-actions">
                                <!-- دکمه ثبت دامنه جدید -->
                                <?php if ( $license['current_count'] < $license['max_domains'] ) : ?>
                                    <button class="rl-btn rl-btn-primary rl-btn-add-domain" 
                                            data-product-id="<?php echo esc_attr( $license['product_id'] ); ?>"
                                            data-order-item-id="<?php echo esc_attr( $license['order_item_id'] ); ?>">
                                        <span class="dashicons dashicons-plus"></span> <?php _e( 'ثبت دامنه', 'readylicense' ); ?>
                                    </button>
                                <?php endif; ?>

                                <!-- دکمه تمدید (اگر قابلیت تمدید فعال باشد) -->
                                <?php if ( ! empty( $license['domains'] ) && ! empty( $license['renewal_price'] ) ) : ?>
                                    <?php foreach ( $license['domains'] as $domain ) : ?>
                                        <button class="rl-btn rl-btn-success rl-btn-renew"
                                                data-product-id="<?php echo esc_attr( $license['product_id'] ); ?>"
                                                data-domain="<?php echo esc_attr( $domain ); ?>"
                                                data-price="<?php echo esc_attr( $license['renewal_price'] ); ?>">
                                            <?php _e( 'تمدید', 'readylicense' ); ?>
                                        </button>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </td>

                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    <?php endif; ?>

    <!-- مودال ثبت دامنه (ساده و سبک بدون نیاز به کتابخانه) -->
    <div id="rl-domain-modal" class="rl-modal">
        <div class="rl-modal-content">
            <span class="rl-close-modal">&times;</span>
            <h3><?php _e( 'ثبت دامنه جدید', 'readylicense' ); ?></h3>
            <p class="rl-modal-desc"><?php _e( 'لطفاً آدرس دامنه خود را بدون http یا www وارد کنید.', 'readylicense' ); ?></p>
            
            <form id="rl-add-domain-form">
                <input type="text" name="domain" placeholder="example.com" required class="rl-input">
                <input type="hidden" name="product_id" id="modal-product-id">
                <input type="hidden" name="order_item_id" id="modal-order-item-id">
                
                <button type="submit" class="rl-btn rl-btn-primary block">
                    <?php _e( 'ذخیره دامنه', 'readylicense' ); ?>
                </button>
            </form>
        </div>
    </div>

</div>